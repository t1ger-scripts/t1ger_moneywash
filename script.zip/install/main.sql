-- ============================================================
-- T1GER Money Wash - Installation SQL
-- Run this file once on first installation
-- ============================================================

-- Player reputation
CREATE TABLE IF NOT EXISTS `moneywash_reputation` (
    `id`           INT(11)      NOT NULL AUTO_INCREMENT,
    `identifier`   VARCHAR(100) NOT NULL,               -- player identifier (license)
    `points`       INT(11)      NOT NULL DEFAULT 0,      -- total reputation points
    PRIMARY KEY (`id`),
    UNIQUE KEY `identifier` (`identifier`)
);

-- Business ownership and live state
CREATE TABLE IF NOT EXISTS `moneywash_businesses` (
    `id`                INT(11)      NOT NULL AUTO_INCREMENT,
    `identifier`        VARCHAR(100) NOT NULL,               -- owner player identifier
    `business_type`     VARCHAR(50)  NOT NULL,               -- matches type key in shared/locations.lua
    `location_id`       INT(11)      NOT NULL,               -- matches id key in shared/locations.lua
    `location_x`        DECIMAL(12,6) NOT NULL,              -- immutable purchased-location snapshot
    `location_y`        DECIMAL(12,6) NOT NULL,
    `location_z`        DECIMAL(12,6) NOT NULL,
    `stock`             INT(11)      NOT NULL DEFAULT 0,      -- current stock units held
    `safe_covered`      BIGINT(20)   NOT NULL DEFAULT 0,      -- clean covered funds in Safe
    `safe_exposed`      BIGINT(20)   NOT NULL DEFAULT 0,      -- clean exposed funds in Safe
    `suspicion`         FLOAT        NOT NULL DEFAULT 0,      -- current suspicion value (0-100)
    `total_laundered`   BIGINT(20)   NOT NULL DEFAULT 0,      -- gross amount ever laundered
    `purchased_at`      BIGINT(20)   NOT NULL DEFAULT 0,      -- unix timestamp of purchase
    PRIMARY KEY (`id`),
    UNIQUE KEY `owner` (`identifier`),                          -- one business per player
    UNIQUE KEY `business_location` (`business_type`, `location_id`) -- one owner per location
);

-- Stock purchase receipts
CREATE TABLE IF NOT EXISTS `moneywash_receipts` (
    `id`           INT(11)    NOT NULL AUTO_INCREMENT,
    `business_id`  INT(11)    NOT NULL,                  -- references moneywash_businesses.id
    `units`        INT(11)    NOT NULL,                  -- units delivered
    `unit_price`   INT(11)    NOT NULL,                  -- price per unit at time of purchase
    `total_amount` INT(11)    NOT NULL,                  -- total clean money paid
    `created_at`   BIGINT(20) NOT NULL,                  -- unix timestamp of delivery completion
    PRIMARY KEY (`id`),
    KEY `business_id` (`business_id`)
) AUTO_INCREMENT = 1000;

-- Bank deposits
CREATE TABLE IF NOT EXISTS `moneywash_deposits` (
    `identifier`  VARCHAR(100)    NOT NULL,                             -- owner player identifier
    `business_id` INT(11)         NOT NULL,                             -- the business the money came from
    `amount`      BIGINT(20)      NOT NULL,                             -- gross amount taken from the Safe
    `covered`     INT             NOT NULL DEFAULT 0,
    `exposed`     INT             NOT NULL DEFAULT 0,
    `x`           DECIMAL(12,6)   DEFAULT NULL,                         -- where it was submitted (set at the ATM)
    `y`           DECIMAL(12,6)   DEFAULT NULL,
    `z`           DECIMAL(12,6)   DEFAULT NULL,
    `state`       VARCHAR(16)     NOT NULL DEFAULT 'enroute',           -- 'enroute' | 'processing'
    `flagged`     TINYINT(1)      NOT NULL DEFAULT 0,                   -- 1 = police were alerted
    `clears_at`   BIGINT(20)      DEFAULT NULL,                         -- unix timestamp the deposit clears (processing only)
    `created_at`  BIGINT(20)      NOT NULL DEFAULT 0,                   -- unix timestamp the deposit was started
    PRIMARY KEY (`identifier`)
);

-- Cash bags: one row per t1ger_cashdeposit item, from the withdrawal until it is paid out
CREATE TABLE IF NOT EXISTS `moneywash_cashbags` (
    `id`          INT(11)         NOT NULL AUTO_INCREMENT,              -- the bagId stored in the item metadata
    `owner`       VARCHAR(100)    NOT NULL,                             -- identifier of the player who withdrew it
    `business_id` INT(11)         NOT NULL,                             -- the business the money came from (the business may be gone later)
    `label`       VARCHAR(100)    NOT NULL,                             -- business name at withdrawal, shown in the bag menu
    `amount`      BIGINT(20)      NOT NULL,                             -- gross amount taken from the Safe
    `state`       VARCHAR(16)     NOT NULL DEFAULT 'carried',           -- 'carried' | 'processing' | 'lost'
    `depositor`   VARCHAR(100)    DEFAULT NULL,                         -- identifier of whoever deposited it (processing only)
    `flagged`     TINYINT(1)      NOT NULL DEFAULT 0,                   -- 1 = police were alerted
    `x`           DECIMAL(12,6)   DEFAULT NULL,                         -- where it was deposited (processing only)
    `y`           DECIMAL(12,6)   DEFAULT NULL,
    `z`           DECIMAL(12,6)   DEFAULT NULL,
    `clears_at`   BIGINT(20)      DEFAULT NULL,                         -- unix timestamp the deposit clears (processing only)
    `created_at`  BIGINT(20)      NOT NULL DEFAULT 0,                   -- unix timestamp the bag was created
    PRIMARY KEY (`id`),
    KEY `owner` (`owner`),
    KEY `depositor` (`depositor`),
    KEY `state` (`state`)
);