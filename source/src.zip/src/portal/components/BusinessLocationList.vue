<script setup lang="ts">
import { computed, nextTick, ref, watch } from 'vue'
import { Building2, SearchX } from '@lucide/vue'
import { useI18n } from 'vue-i18n'

import AppBadge from '@/portal/components/ui/AppBadge.vue'
import AppSearchInput from '@/portal/components/ui/AppSearchInput.vue'
import AppSurface from '@/portal/components/ui/AppSurface.vue'
import { usePortalStore } from '@/portal/stores/portal.store.js'
import { formatNumber } from '@/portal/utils/formatters.js'

import BusinessLocationListItem from './BusinessLocationListItem.vue'

const portalStore = usePortalStore()
const { locale, t } = useI18n()

const locationListElement = ref<HTMLDivElement | null>(null)

const selectedTier = computed(
    () => portalStore.selectedTier,
)

const locations = computed(
    () => portalStore.filteredLocations,
)

const availabilitySummary = computed(() => {
    const tier = selectedTier.value
    if (!tier) return ''

    return t('portal.businessList.availability', {
        available: formatNumber(
            tier.availableLocationCount,
            locale.value,
        ),
        total: formatNumber(
            tier.totalLocationCount,
            locale.value,
        ),
    })
})

const emptyStateTranslation = computed(() => {
    if (portalStore.selectedTierLocations.length === 0) {
        return 'portal.businessList.noLocations'
    }

    return 'portal.businessList.noSearchResults'
})

async function scrollSelectedLocationIntoView(
    locationId: string,
): Promise<void> {
    if (!locations.value.some((location) => location.id === locationId)) {
        portalStore.setSearchQuery('')
    }

    await nextTick()

    const listElement = locationListElement.value

    if (!listElement) {
        return
    }

    const selectedItem = Array.from(
        listElement.querySelectorAll<HTMLElement>(
            '[data-location-id]',
        ),
    ).find(
        (item) => item.dataset.locationId === locationId,
    )

    selectedItem?.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
        inline: 'nearest',
    })
}

watch(
    () => portalStore.selectedLocationId,
    (locationId) => {
        if (!locationId) {
            return
        }

        void scrollSelectedLocationIntoView(locationId)
    },
    {
        immediate: true,
        flush: 'post',
    },
)

function selectLocation(locationId: string): void {
    portalStore.selectLocation(locationId)
}

function updateSearchQuery(value: string): void {
    portalStore.setSearchQuery(value)
}
</script>

<template>
    <AppSurface v-if="selectedTier" class="business-list">
        <header class="business-list__header">
            <div class="business-list__heading">
                <h2>{{ selectedTier.displayName }}</h2>

                <AppBadge tone="primary" shape="rounded">
                    {{
                        t('portal.tierSelector.tier', {
                            number: selectedTier.tierNumber,
                        })
                    }}
                </AppBadge>

                <span class="business-list__availability">
                    {{ availabilitySummary }}
                </span>
            </div>

            <AppSearchInput :model-value="portalStore.searchQuery" :label="t('portal.businessList.searchLabel')"
                :placeholder="t('portal.businessList.searchPlaceholder')"
                :clear-label="t('portal.businessList.clearSearch')" @update:model-value="updateSearchQuery" />
        </header>

        <div v-if="locations.length > 0" ref="locationListElement" class="business-list__locations app-scrollbar">
            <BusinessLocationListItem v-for="location in locations" :key="location.id" :location="location"
                :currency-symbol="portalStore.currencySymbol" :selected="portalStore.selectedLocationId === location.id
                    " @select="selectLocation" />
        </div>

        <div v-else class="business-list__empty">
            <SearchX v-if="portalStore.searchQuery" :size="30" aria-hidden="true" />

            <Building2 v-else :size="30" aria-hidden="true" />

            <p>{{ t(emptyStateTranslation) }}</p>
        </div>
    </AppSurface>
</template>

<style scoped lang="scss">
.business-list {
    display: grid;
    min-width: 0;
    min-height: 0;
    overflow: hidden;
    grid-template-rows: auto minmax(0, 1fr);

    &__header {
        display: grid;
        gap: var(--space-4);
        padding: var(--space-4);
        border-bottom: var(--border-width) solid var(--color-border);
    }

    &__heading {
        display: flex;
        min-width: 0;
        align-items: center;
        gap: var(--space-3);

        h2 {
            flex: 0 0 auto;
            overflow: hidden;
            color: var(--color-text-primary);
            font-size: var(--font-size-lg);
            line-height: var(--line-height-tight);
            text-overflow: ellipsis;
            white-space: nowrap;
        }
    }

    &__availability {
        min-width: 0;
        margin-left: auto;
        overflow: hidden;
        color: var(--color-text-secondary);
        font-size: var(--font-size-xs);
        line-height: var(--line-height-tight);
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    &__locations {
        min-height: 0;
        overflow-y: auto;
        padding: var(--space-2);
    }

    &__empty {
        display: grid;
        min-height: 12rem;
        align-content: center;
        justify-items: center;
        gap: var(--space-3);
        padding: var(--space-6);
        color: var(--color-text-muted);
        text-align: center;

        p {
            max-width: 18rem;
            font-size: var(--font-size-sm);
            line-height: var(--line-height-normal);
        }
    }
}
</style>